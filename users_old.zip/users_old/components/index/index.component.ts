import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { UserService } from '../../services/user.service';
import { DataTableDirective } from 'angular-datatables';
import {Subject, from} from 'rxjs';

@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.css']
})

export class IndexComponent implements OnInit {

  baseUrl: string;
  dtOptions: DataTables.Settings = {};
  dtElement: DataTableDirective;
  dtTrigger: Subject<any> = new Subject();
  UserData: [];

  constructor(
    private http: HttpClient,
    public UserService: UserService,
  ) {
    this.baseUrl = environment.baseUrl;
  }

  ngOnInit(): void {
    console.log(this.dtOptions);
    const that = this;
    this.dtOptions = {
      order: [[0, 'desc']],
      pagingType: 'full_numbers',
      pageLength: 10,
      serverSide: true,
      processing: true,
      responsive: true,
      searching: false,
      lengthChange: false,
      ajax: (dataTablesParameters: any, callback) => that.getUserData(callback),
      columns: [
        {
          title: 'Id',
          data: 'id',
          visible: false
        },
        
      ],
    };
  }

  getUserData(callback) {

    let data = {
    }

    this.UserService.getUserData(data).then((response) => {
      this.UserData = response.data;
      console.log(this.UserData);
      callback({
        recordsTotal: response.recordsTotal,
        recordsFiltered: response.recordsFiltered,
        data: response.data
      });
    }).catch((error) => {
      callback({
        recordsTotal: 0,
        recordsFiltered: 0,
        data: []
      });
    });
  }

}
